current_path = pwd;
% Add Folder and Its Subfolders to Search Path. We need the subfolder 'BoostGraphLibrary'
addpath(genpath(current_path)); 